#ifndef GEN_INFO_H
#define GEN_INFO_H
//
//enum StatMods {
//	ATK = 0,
//	DEF = 1,
//	AGI = 2,
//	KNO = 3,
//	FRE_DMG = 4,
//	CLD_DMG = 5,
//	LGT_DMG = 6,
//	CHS_DMG = 7
//};

#endif